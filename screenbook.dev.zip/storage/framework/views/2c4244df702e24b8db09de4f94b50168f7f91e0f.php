<?php $__env->startSection('title', 'Blog'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('partials.blogcss', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<section id="home" class="sliderwrapper clearfix">
    
       <div class="tp-banner-container">
         
            <div class="tp-dottedoverlay twoxtwo"></div>
            <section id="contact" class="contact-wrapper">
                <div class="title text-center">
                <h2>SCREENBOOK.NG BLOG</h2>
                <h5><p>Education Information Orientation Entertainment</p></h5>
               </div>
            </div>
        </div>
    </section> 
         
  
   <section id="features" >
  <div  class="title text-center" >
            <h2>blog Posts</h2>
            <hr>
        </div>
    </div>
    </section>        
    <!--/ SERVICE SECTION -->   
    <section >
    <div class="blog" id="blog">   
        <div class="container">
           <div class=" main-content col-lg-8  col-md-10 col-md-offset-2 mx-auto">
          <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

          <div class="post-preview">
            <a href="/post/<?php echo e($post->slug); ?>">

              <h2 class="post-title">
                <?php echo e($post->title); ?>

              </h2>
              <h3 class="post-subtitle">
                <?php echo e($post->excerpt); ?>

              </h3>
            </a>
            <p class="post-meta">Posted by
              <a href="#"><?php echo e($post->author->name); ?></a>
              <?php echo e(Date('F, nS Y g:i A', strtotime($post->created_at))); ?></p>
            <hr>
            </div>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            </div>
        </div><!-- end #testimonial -->
        </div><!-- end customnav -->
    </div> <!-- end container -->
    </section><!-- Service and Testimonial End --> 
       
    <!--/ VIDEO PARALLAX SECTINO  -->   
    <section class="videobg clearfix text-center">
        
                 <div class ="col-md-10 " > 
                 <?php echo e($posts->links()); ?>

                  </div>
               </div><!-- end container -->
            </div>
     </div>
    </div>
   </div>
</section><!--/ Video Parallex  End --> 
<?php echo $__env->make('partials.blogscr', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
 <?php $__env->stopSection(); ?>
    

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>