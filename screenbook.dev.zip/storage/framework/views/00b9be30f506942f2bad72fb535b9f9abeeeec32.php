<?php $__env->startSection('title', 'Blog'); ?>

<?php $__env->startSection('content'); ?>


<section>
       <div class="tp-banner-container">
            <div class="tp-banner">
            <ul>
              <li data-transition="fade" data-slotamount="7" data-masterspeed="1500" >
                        <!-- MAIN IMAGE -->
                        <img src="<?php echo e(asset('/demos/slider2.jpg')); ?>"  alt="slidebg1"  data-bgfit="cover" data-bgposition="center center" data-bgrepeat="no-repeat">
                <div class="tp-dottedoverlay twoxtwo"></div>
 
                        <!-- LAYER NR. 3 -->
                         <div class="tp-caption rev-video  customin customout start"
                            data-x="center"
                            data-hoffset="0"
                            data-y="140"
                            data-customin="x:0;y:0;z:0;rotationX:90;rotationY:0;rotationZ:0;scaleX:1;scaleY:1;skewX:0;skewY:0;opacity:0;transformPerspective:200;transformOrigin:50% 0%;"
                            data-customout="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0.75;scaleY:0.75;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
                            data-speed="1000"
                            data-start="500"
                            data-easing="Back.easeInOut"
                            data-endspeed="300"><hr class="topline"><h2>SCREENBOOK.NG BLOG</h2><hr class="bottomline">
                        </div>
    
                        <!-- LAYER NR. 4 -->
                         <div class="tp-caption rev-video2 customin customout start"
                            data-x="center"
                            data-hoffset="0"
                            data-y="340"
                            data-customin="x:0;y:0;z:0;rotationX:90;rotationY:0;rotationZ:0;scaleX:1;scaleY:1;skewX:0;skewY:0;opacity:0;transformPerspective:200;transformOrigin:50% 0%;"
                            data-customout="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0.75;scaleY:0.75;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
                            data-speed="2200"
                            data-start="500"
                            data-easing="Back.easeInOut"
                            data-endspeed="300"><p>Education Information<br>Orientation Entertainment
                            </p>
                        </div>
                    </li>
              </ul>
            </div>
        </div>
    </section><!-- end slider-wrapper -->   
         
   
  
   <section id="features" class="feature-wrapper">
  <div data-scroll-reveal="enter from the bottom after 0.3s" class="title text-center" data-scroll-reveal-id="2" data-scroll-reveal-initialized="true" data-scroll-reveal-complete="true">
            <h2>blog Posts</h2>
            <hr>
        </div>
    </div>
            
    <!--/ SERVICE SECTION -->   
    <section >
    <div class="blog" id="blog">   
        <div class="container">
           <div class=" main-content col-lg-8  col-md-10 col-md-offset-2 mx-auto">
          <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

          <div class="post-preview">
            <a href="/post/<?php echo e($post->slug); ?>">

              <h2 class="post-title">
                <?php echo e($post->title); ?>

              </h2>
              <h3 class="post-subtitle">
                <?php echo e($post->excerpt); ?>

              </h3>
            </a>
            <p class="post-meta">Posted by
              <a href="#"><?php echo e($post->author->name); ?></a>
              <?php echo e(Date('F, nS Y g:i A', strtotime($post->created_at))); ?></p>
            <hr>
            </div>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            </div>
        </div><!-- end #testimonial -->
        </div><!-- end customnav -->
    </div> <!-- end container -->
    </section><!-- Service and Testimonial End --> 
       
    <!--/ VIDEO PARALLAX SECTINO  -->   
    <section class="videobg clearfix text-center">
        
                 <div class ="col-md-10 " > 
                 <?php echo e($posts->links()); ?>

                  </div>
               </div><!-- end container -->
            </div>
     </div>
    </div>
   </div>
</section><!--/ Video Parallex  End -->  
<?php echo $__env->make('partials.blogscr', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
 <?php $__env->stopSection(); ?>
    

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>