	<!-- Bootstrap -->
    <link rel="stylesheet" href="<?php echo e(asset('/css/bootstrap.css')); ?>">
    <!-- end Google Font -->
    

    <link href='http://fonts.googleapis.com/css?family=Raleway:400,500,600,700,800,300' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Oswald:400,500,600,700,800,300' rel='stylesheet' type='text/css'>
    <!-- owl carousel SLIDER -->
    <link rel="stylesheet" href="<?php echo e(asset('/css/owl.carousel.css')); ?>">
    <!-- end awesome icons -->
    <link rel="stylesheet" href="<?php echo e(asset('/css/font-awesome.css')); ?>">
    <!-- lightbox -->
    <link href="<?php echo e(asset('/css/prettyPhoto.css')); ?>" rel="stylesheet">
    
    <!-- Animation Effect CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('/css/animation.css')); ?>">
    <!-- Main Stylesheet CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('/css/style.css')); ?>">
    
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
	<!--[if lt IE 9]>
	  <script src="js/html5shiv.js"></script>
	  <script src="js/respond.min.js"></script>
	<![endif]-->

	<!-- SLIDER REVOLUTION 4.x CSS SETTINGS -->
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('/rs-plugin/css/settings.css')); ?>" media="screen" />


  <!-- Bootstrap core CSS -->
    <link href="/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

   


    