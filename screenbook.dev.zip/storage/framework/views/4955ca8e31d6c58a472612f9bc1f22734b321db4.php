<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <link rel="icon"  href="<?php echo e(url('images/icon.png')); ?>">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>Screenbook | <?php echo $__env->yieldContent('title'); ?></title>

    <!-- Styles -->
  
    <?php echo $__env->make('partials.style', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>
<body data-spy="scroll" data-offset="25">
    <div id="app">
        
        <?php echo $__env->make('partials.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        
           <?php echo $__env->yieldContent('header'); ?>

           <?php echo $__env->yieldContent('content'); ?>

        <?php echo $__env->make('partials.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>

    <!-- Scripts -->
    <?php echo $__env->make('partials.script', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
   
</body>
</html>
