 <!--/ FOOTER SECTION-->  
    <section id="footer" class="footer-wrapper text-center">
        <div class="container">
            <div class="title text-center" data-scroll-reveal="enter from the bottom after 0.5s">
               <div class="aligncenter">     
				  <a href="index.html" class="navbar-brand">Screenbook.ng<br> <span class="slogo">...making learning ridiculously simple<span></a>
                 
                    <div class="socialFooter title text-right">
                        <a href="#"><i class="fa fa-facebook"></i></a>
                        <a href="#"><i class="fa fa-twitter"></i></a>
                
                        <a href="#"><i class="fa fa-linkedin"></i></a>
                       
                        <a href="#"><i class="fa fa-instagram"></i></a>
                       
                    
                    </div>
               		<!-- don't removed this as we are providing it for free -->
    	<p>Designed by © 2017 <a href="http://www.screenbook.ng">SCREENBOOK.NG</a></p>
                <a data-scroll-reveal="enter from the bottom after 0.3s" href="#"><i class="fa fa-angle-up"></i></a>
            </div>    <!-- end title -->
        </div>  <!-- end container -->
    </section><!--/ Footer  End --> 
     