<?php $__env->startSection('title', 'Blog'); ?>
<?php echo $__env->make('partials.blogcss', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('content'); ?>


    
    <section id="home" class="sliderwrapper clearfix">
  
    <div class="tp-banner-container">
               
    <header class="masthead" style="background-image:url('/img/home-bg.jpg')">
      <div class="container">
        <div class="row">
          <div class="col-lg-8 col-md-10 col-md-offset-2 mx-auto">
            <div class="site-heading">
              <h2>SCREENBOOK.NG BLOG</h2>
              <hr class ="small">
              <span class="subheading">Orientation Education Information Entertainment</span>
            </div>
          </div>
        </div>
    </div>
    </section><!-- end slider-wrapper -->  
         
   
  
   <section id="features" class="feature-wrapper">
     <div class="container">
  <div data-scroll-reveal="enter from the bottom after 0.3s" class="title text-center" data-scroll-reveal-id="2" data-scroll-reveal-initialized="true" data-scroll-reveal-complete="true">
            <h2>blog Posts</h2>
            <hr>
        </div>
    </div>
            
    <!--/ SERVICE SECTION -->   
    <section id="services" class="white-wrapper">
        <div class="container">
           <div class="col-lg-8  col-md-10 col-md-offset-2 mx-auto">
          <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

          <div class="post-preview">
            <a href="/post/<?php echo e($post->slug); ?>">

              <h2 class="post-title">
                <?php echo e($post->title); ?>

              </h2>
              <h3 class="post-subtitle">
                <?php echo e($post->excerpt); ?>

              </h3>
            </a>
            <p class="post-meta">Posted by
              <a href="#"><?php echo e($post->author->name); ?></a>
              <?php echo e(Date('F, nS Y g:i A', strtotime($post->created_at))); ?></p>
            <hr>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            </div>
            </div><!-- end #testimonial -->
            </div><!-- end customnav -->
       </div> <!-- end container -->
    </section><!-- Service and Testimonial End --> 
       
    <!--/ VIDEO PARALLAX SECTINO  -->   
    <section class="videobg clearfix text-center">
        
                 <div class ="col-md-10 " > 
                 <?php echo e($posts->links()); ?>

                  </div>
               </div><!-- end container -->
            </div>
     </div>
    </div>
   </div>
</section><!--/ Video Parallex  End -->  
<?php echo $__env->make('partials.blogscr', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
 <?php $__env->stopSection(); ?>
    

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>