 <!--/ FOOTER SECTION-->  
    <section id="footer" class="footer-wrapper text-center">
        <div class="container">
            <div class="title text-center" data-scroll-reveal="enter from the bottom after 0.5s">
            <div class="container text-center">

              <div class="title text-center">
                   <a href="<?php echo e(url('https://www.facebook.com/ScreenBook.Ng/')); ?>"><i class="fa     fa-facebook"></i></a>
                        <a href="<?php echo e(url('https://twitter.com/screenbook_ng')); ?>"><i class="fa fa-twitter"></i></a>
                        <a href="#"><i class="fa fa-linkedin"></i></a>
                        <a href="<?php echo e(url('https://www.instagram.com/ScreenBook.Ng/')); ?>"><i class="fa fa-instagram"></i></a>
                    </div>
    <hr />
  <div class="row">
    <div class="col-lg-12">
      <div class="col-md-3">
        <ul>
          <li><a href="<?php echo e(('/')); ?>">Home</a></li>
          <li><a href="<?php echo e(('/about')); ?>">About us</a></li>
        </ul>
      </div>
      <div class="col-md-3">
        <ul>
          <li><a href="<?php echo e(('/blog')); ?>">Blog</a></li>
          <li><a href="<?php echo e(url('https://screenbooktutoring.slack.com')); ?>">Slack channel </a></li>
        </ul>
      </div>
      <div class="col-md-3">
        <ul>
          <li><a href="<?php echo e(('/contact')); ?>">Contact us</a></li>
          <li><a href="#">Privacy & terms</a></li>          
        </ul>
      </div>
      <div class="col-md-3">
        <ul>
          <li>362 Peridot fuel Station <br/>Isheri Lagos, Nigeria</li>
          <li>(+234) 0813-618-1285 </li>
        </ul>
      </div>  
    </div>
  </div>

               
                 




  <hr>
    <div class="row">
        <div class="col-lg-12">
            <ul >
                <li><a href="/">© Sceenbook.ng 2017</a></li>
            </ul>
        </div>
    </div>
     <a data-scroll-reveal="enter from the bottom after 0.3s" href="#"><i class="fa fa-angle-up"></i></a>
</div>

               		<!-- don't removed this as we are providing it for free
    	
               
            </div>    <!-- end title -->
        </div>  <!-- end container -->
    </section><!--/ Footer  End --> 
     