<?php $titleTag = htmlspecialchars($post->title); ?>
<?php $__env->startSection('title', " $titleTag"); ?>
<?php echo $__env->make('partials.blogcss', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('content'); ?>


<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_GB/sdk.js#xfbml=1&version=v2.10&appId=152250022047218";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>

  <section>
    <div class="tp-banner-container">      
     <header class="masthead" style="background-image: url('/<?php echo e($post->image); ?>')">
        <div class="row">
          <div class="col-lg-8 col-md-10 col-md-offset-2 mx-auto">
            <div class="site-heading">
              <h1><?php echo e($post->title); ?></h1>
              <hr class ="small">
              <h2 class="subheading"><?php echo e($post->seo_title); ?></h2>
              <span class="#">Posted by
                <a href="#">Screenbook.ng</a>
                 <?php echo e(Date('F, nS Y g:i A', strtotime($post->created_at))); ?></span>
            </div>
          </div> 
        </div>
    </div>
    </section><!-- end slider-wrapper -->  
         
   
  
   <section id="features" class="feature-wrapper">
     <div class="container">
  <div data-scroll-reveal="enter from the bottom after 0.3s" class="title " data-scroll-reveal-id="2" data-scroll-reveal-initialized="true" data-scroll-reveal-complete="true">
   
    <div class ="col-md-8 col-md-offset-2">
    <div class="row">
    
            <?php echo $post->body; ?>

          </div>
        </div>
      </div>
    </div>
</div>
</div><!-- end col-lg-6 -->
 </section>
  
            
    
     <section id="services" class="white-wrapper">
        <div class="container">
        <div class="col-lg-8 col-md-offset-2 col-md-10 mx-auto">
            <div class="title text-center">

             <div class="fb-post" data-href="https://localhost:8000" data-show-text="5"></div>

        
              <div class="service-box">      
                <ul>
                <p><span class="glyphicon glyphicon-comment"></span> <?php echo e($post->comments()->count()); ?> Comments 
                </p>

                      <?php $__currentLoopData = $comment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li>
                    <div class="comment">
                      <div class="comment-img">
                        <img src="http://placehold.it/170x170" alt="">
                      </div>
                      <div class="comment-detail">
                        <div class="comment-name">
                        <div class="comment-name">
                          <strong><?php echo e($c->name); ?></strong>
                          <i><?php echo e(Date('F j, Y ', strtotime($c->created_at))); ?></i>                         
                        </div>              
                        <?php echo e($c->comment); ?>

                        </div>   
                    </div><!-- Comment -->
                    </li>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
              </div> 
            </div> 
        </section>
    

    <!-- SERVICE SECTION -->   
      
     <div> 
      <ul>
      <?php $__currentLoopData = $comment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li>
          <?php echo e($c->comment); ?>

      </li>   
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     </ul>
   </div>
     
    <!--/ VIDEO PARALLAX SECTINO  -->   
    <section class="videobg clearfix text-center">
        <div class="videooverlay" data-scroll-reveal="enter from the bottom after 0.4s">
        <div class="container">
         <div class="service-box">
        <div class="col-lg-8 col-md-offset-2 col-md-10 mx-auto">
         <form action = "<?php echo e(URL::to('add/comment')); ?>" method="post" >
            <?php echo e(csrf_field()); ?>


        <textarea name ="comment" class ="form-control" id="" rows="6" cols="30"></textarea>
        <input type="hidden" class ="form-control "name = "post_id" value="<?php echo e($post->id); ?>" >
        <input type="submit" class ="form-control jtbtn" value ="Add Comment">
        </form>   
             
     </div><!-- end col-lg-6 -->
     </div><!-- end container -->
    </section><!-- end grey-wrapper -->
       </div>
      </div>
      </div>
     <div class="col-lg-8  col-md-10 col-md-offset-8 mx-auto">
    <a href="<?php echo e(url('blog')); ?>" class ="jtbtn btn-primary" >ALL Post</a>
    </div>
     </div>
    </div>
   </div>
</section><!--/ Video Parallex  End -- >
    
<?php echo $__env->make('partials.blogscr', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
    

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>