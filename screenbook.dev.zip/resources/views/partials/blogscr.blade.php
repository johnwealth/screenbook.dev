      <!-- Bootstrap blog core JavaScript -->
   
    <script src="/vendor/jquery/jquery.min.js"></script>
    <script src="/vendor/popper/popper.min.js"></script>
   

    <!-- Custom scripts for this template -->
    <script src="/js/clean-blog.min.js"></script>