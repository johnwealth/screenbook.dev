 <header class="header">
        <div class="container">
            <div class="navbar navbar-default" role="navigation">
                <div class="container-fluid">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        </button>
                        <a href="{{('/')}}" class="navbar-brand"><img src = "{{asset('/demos/icon.png')}}"/></a>
                    </div><!-- end navbar-header -->
                    <div class="navbar-collapse collapse">
                        <ul class="nav navbar-nav navbar-right">
                        <li><a data-scroll href="{{('/')}}" class="int-collapse-menu">Home</a></li>
                         <li><a data-scroll href="{{('/about')}}" class="int-collapse-menu">About</a></li>
                        <li><a data-scroll href="{{('/blog')}}" class="int-collapse-menu">Blog</a></li>
                        <li><a data-scroll href="{{('/contact')}}" class="int-collapse-menu">Contact</a></li>
                          <!--   <li class="active"><a data-scroll href="#download" class="int-collapse-menu">Download</a></li> -->
                         <!--  <li><a data-scroll href="#services" class="int-collapse-menu">Services</a></li> -->
                         <!--   <li><a data-scroll href="{{('/video')}}" class="int-collapse-menu">Video Aids</a></li>
                        <li><a data-scroll href="#team" class="int-collapse-menu">Team</a></li>
                        <li><a data-scroll href="{{('/practice')}}" class="int-collapse-menu">Practice Test</a></li> -->
                       <!--  <li><a data-scroll href="#features" class="int-collapse-menu">Why Us ?</a></li> -->
                        </ul>
                    </div><!--/.nav-collapse -->
                </div><!--/.container-fluid -->
            </div>
        </div><!-- end container -->
    </header><!-- end header -->